import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class HeartDiseaseSymptomsForm extends StatefulWidget {
  @override
  _HeartDiseaseSymptomsForm createState() => _HeartDiseaseSymptomsForm();
}

class _HeartDiseaseSymptomsForm extends State<HeartDiseaseSymptomsForm> {
  final _formKey = GlobalKey<FormState>();
  late DatabaseReference _databaseRef;

  TextEditingController _ageController = TextEditingController();
  TextEditingController _bmiController = TextEditingController();

  List<String> symptoms = [
    'Diabetes_012',
    'HighBP',
    'HighChol',
    'CholCheck',
    'Smoker',
    'Stroke',
  //  'HeartDiseaseorAttack',
    'PhysActivity',
    'Fruits',
    'Veggies',
    'HvyAlcoholConsump',
    'AnyHealthcare',
    'NoDocbcCost',
    'DiffWalk',
    'Sex',
  ];

  String selectedAge = '';
  String BMI = '';

  Map<String, bool> selectedSymptoms = {};

  @override
  void initState() {
    super.initState();
    symptoms.sort(); // Sort the symptoms in alphabetical order

    // Initialize selectedSymptoms map
    symptoms.forEach((symptom) {
      selectedSymptoms[symptom] = false;
    });

    // Initialize Firebase Realtime Database reference
    _databaseRef = FirebaseDatabase.instance.ref().child('heart_disease');
  }

  void saveData() {
    if (_formKey.currentState!.validate()) {
      selectedAge = _ageController.text;
      BMI = _bmiController.text;

      _databaseRef.push().set({
        'age': selectedAge,
        'BMI': BMI,
        'symptoms': selectedSymptoms,
      }).then((_) {
        // Data saved successfully
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Data saved successfully')),
        );
      }).catchError((error) {
        // Error occurred while saving data
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save data: $error')),
        );
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Heart Attack Symptoms Form'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Please enter your information and select symptoms:',
                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16.0),
                TextFormField(
                  controller: _ageController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Age',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your age';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _bmiController,
                  decoration: InputDecoration(
                    labelText: 'BMI',
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter your BMI(Body Mass Index)';
                    }
                    return null;
                  },
                ),

                SizedBox(height: 16.0),
                Text(
                  'Select Symptoms:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  children: symptoms.map((symptom) {
                    return CheckboxListTile(
                      title: Text(symptom),
                      value: selectedSymptoms[symptom],
                      onChanged: (value) {
                        setState(() {
                          selectedSymptoms[symptom] = value!;
                        });
                      },
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: saveData,
                  child: Text('Save Data'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    title: 'Heart Disease Symptoms Collector',
    home: HeartDiseaseSymptomsForm(),
  ));
}
