import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class User {
  final String key;
  final String name;
  final String email;

  User({
    required this.key,
    required this.name,
    required this.email,
  });
}

class UserList extends StatefulWidget {
  @override
  _UserListState createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  late DatabaseReference _usersRef;
  late List<User> _users;

  @override
  void initState() {
    super.initState();
    // Initialize the Realtime Database reference
    _usersRef = FirebaseDatabase.instance.ref().child('users');
    _users = [];

    // Listen for changes in the users data
    _usersRef.onValue.listen((event) {
      final data = event.snapshot.value;
      if (data != null && data is Map) {
        // Clear the existing list of users
        _users.clear();

        // Iterate through the child nodes and create User objects
        data.forEach((key, value) {
          final user = User(
            key: key,
            name: value['name'],
            email: value['email'],
          );
          _users.add(user);
        });

        // Update the UI with the new list of users
        setState(() {});
      }
    });
  }

  void createUser(String name, String email) {
    final newUserRef = _usersRef.push();
    newUserRef.set({
      'name': name,
      'email': email,
    });
  }

  void updateUser(String key, String newName, String newEmail) {
    final userRef = _usersRef.child(key);
    userRef.update({
      'name': newName,
      'email': newEmail,
    });
  }

  void deleteUser(String key) {
    final userRef = _usersRef.child(key);
    userRef.remove();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Users List'),
      ),
      body: ListView.builder(
        itemCount: _users.length,
        itemBuilder: (context, index) {
          final user = _users[index];
          return ListTile(
            title: Text(user.name),
            subtitle: Text(user.email),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () => deleteUser(user.key),
            ),
            onTap: () {
              // Show a dialog to update the user's data
              showDialog(
                context: context,
                builder: (context) {
                  String newName = user.name;
                  String newEmail = user.email;

                  return AlertDialog(
                    title: Text('Update User'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          onChanged: (value) => newName = value,
                          decoration: InputDecoration(labelText: 'Name'),
                          controller: TextEditingController(text: user.name),
                        ),
                        TextField(
                          onChanged: (value) => newEmail = value,
                          decoration: InputDecoration(labelText: 'Email'),
                          controller: TextEditingController(text: user.email),
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        child: Text('Cancel'),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      TextButton(
                        child: Text('Update'),
                        onPressed: () {
                          updateUser(user.key, newName, newEmail);
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          // Show a dialog to create a new user
          showDialog(
            context: context,
            builder: (context) {
              String name = '';
              String email = '';

              return AlertDialog(
                title: Text('Create User'),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      onChanged: (value) => name = value,
                      decoration: InputDecoration(labelText: 'Name'),
                    ),
                    TextField(
                      onChanged: (value) => email = value,
                      decoration: InputDecoration(labelText: 'Email'),
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    child: Text('Cancel'),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  TextButton(
                    child: Text('Create'),
                    onPressed: () {
                      createUser(name, email);
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
