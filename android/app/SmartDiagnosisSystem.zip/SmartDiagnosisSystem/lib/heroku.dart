import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SymptomsFormm extends StatefulWidget {
  @override
  _SymptomsFormmState createState() => _SymptomsFormmState();
}

class _SymptomsFormmState extends State<SymptomsFormm> {
  TextEditingController highBPController = TextEditingController();
  TextEditingController highCholController = TextEditingController();
  TextEditingController cholCheckController = TextEditingController();
  TextEditingController bmiController = TextEditingController();
  TextEditingController smokerController = TextEditingController();
  TextEditingController strokeController = TextEditingController();
  TextEditingController diabetesController = TextEditingController();
  TextEditingController physActivityController = TextEditingController();
  TextEditingController fruitsController = TextEditingController();
  TextEditingController veggiesController = TextEditingController();
  TextEditingController hvyAlcoholConsumpController = TextEditingController();
  TextEditingController anyHealthcareController = TextEditingController();
  TextEditingController noDocbcCostController = TextEditingController();
  TextEditingController genHlthController = TextEditingController();
  TextEditingController mentHlthController = TextEditingController();
  TextEditingController physHlthController = TextEditingController();
  TextEditingController diffWalkController = TextEditingController();
  TextEditingController sexController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController educationController = TextEditingController();
  TextEditingController incomeController = TextEditingController();
  String result = '';

  Future<void> predictPlacement() async {
    String url = "https://2d4d-39-45-214-19.ngrok-free.app/predict";
    Map<String, String> params = {
      "HighBP": highBPController.text,
      "HighChol": highCholController.text,
      "CholCheck": cholCheckController.text,
      "BMI": bmiController.text,
      "Smoker": smokerController.text,
      "Stroke": strokeController.text,
      "Diabetes": diabetesController.text,
      "PhysActivity": physActivityController.text,
      "Fruits": fruitsController.text,
      "Veggies": veggiesController.text,
      "HvyAlcoholConsump": hvyAlcoholConsumpController.text,
      "AnyHealthcare": anyHealthcareController.text,
      "NoDocbcCost": noDocbcCostController.text,
      "GenHlth": genHlthController.text,
      "MentHlth": mentHlthController.text,
      "PhysHlth": physHlthController.text,
      "DiffWalk": diffWalkController.text,
      "Sex": sexController.text,
      "Education": educationController.text,
      "Income": incomeController.text,
    };
    print("Printing Message");
    print(jsonEncode(params));
    try {
      http.Response response = await http.post(Uri.parse(url), body: jsonEncode(params));
      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);
        String data = jsonData["HeartDiseaseorAttack"];
        setState(() {
          result = data == "1" ? "Heart Disease" : "Not a heart disease";
        });
      } else {
        print('Request failed with status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        throw Exception('Failed to fetch data');
      }
    } catch (error) {
      print(error);
    }
  }

  void _predictDisease() {
    // Call the predictPlacement function
    predictPlacement();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Symptoms Collector Form'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    TextFormField(
                      controller: highBPController,
                      decoration: InputDecoration(
                        labelText: 'High Blood Pressure',
                      ),
                    ),
                    TextFormField(
                      controller: highCholController,
                      decoration: InputDecoration(
                        labelText: 'High Cholesterol',
                      ),
                    ),
                    TextFormField(
                      controller: cholCheckController,
                      decoration: InputDecoration(
                        labelText: 'Cholesterol Check',
                      ),
                    ),
                    TextFormField(
                      controller: bmiController,
                      decoration: InputDecoration(
                        labelText: 'BMI',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: smokerController,
                      decoration: InputDecoration(
                        labelText: 'Smoker',
                      ),
                    ),
                    TextFormField(
                      controller: strokeController,
                      decoration: InputDecoration(
                        labelText: 'Stroke',
                      ),
                    ),
                    TextFormField(
                      controller: diabetesController,
                      decoration: InputDecoration(
                        labelText: 'Diabetes',
                      ),
                    ),
                    TextFormField(
                      controller: physActivityController,
                      decoration: InputDecoration(
                        labelText: 'Physical Activity',
                      ),
                    ),
                    TextFormField(
                      controller: fruitsController,
                      decoration: InputDecoration(
                        labelText: 'Fruits',
                      ),
                    ),
                    TextFormField(
                      controller: veggiesController,
                      decoration: InputDecoration(
                        labelText: 'Veggies',
                      ),
                    ),
                    TextFormField(
                      controller: hvyAlcoholConsumpController,
                      decoration: InputDecoration(
                        labelText: 'Heavy Alcohol Consumption',
                      ),
                    ),
                    TextFormField(
                      controller: anyHealthcareController,
                      decoration: InputDecoration(
                        labelText: 'Any Healthcare',
                      ),
                    ),
                    TextFormField(
                      controller: noDocbcCostController,
                      decoration: InputDecoration(
                        labelText: 'No Doctor by Cost',
                      ),
                    ),
                    TextFormField(
                      controller: genHlthController,
                      decoration: InputDecoration(
                        labelText: 'General Health',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: mentHlthController,
                      decoration: InputDecoration(
                        labelText: 'Mental Health',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: physHlthController,
                      decoration: InputDecoration(
                        labelText: 'Physical Health',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: diffWalkController,
                      decoration: InputDecoration(
                        labelText: 'Difficulty in Walking',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: sexController,
                      decoration: InputDecoration(
                        labelText: 'Sex',
                      ),
                    ),
                    TextFormField(
                      controller: ageController,
                      decoration: InputDecoration(
                        labelText: 'Age',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: incomeController,
                      decoration: InputDecoration(
                        labelText: 'Income',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    TextFormField(
                      controller: educationController,
                      decoration: InputDecoration(
                        labelText: 'Education',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _predictDisease,
                      child: Text('Predict Disease'),
                    ),
                    SizedBox(height: 16),
                    Text(result),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: SymptomsFormm(),
  ));
}