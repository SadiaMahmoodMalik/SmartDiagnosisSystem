import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:smartdiagnosissystem/Prediction_Page.dart';

Future<Map<String, dynamic>> makePrediction() async {
  final url =
      'https://ussouthcentral.services.azureml.net/workspaces/e339cb2ecdf047b885e8e56f8c4c7892/services/d1df4ea11add402ea258a67853d558a8/execute?api-version=2.0&format=swagger';

  final apiToken = 'Ia+t383yVkQ/td8VUtwiipHGdz59lYiFVIk2XP6gFuekOfVeuIF2i2mbFE0VZnqRPlrlCwjKjHnh+AMCMz3mpw==';
  final headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $apiToken',
  };

  final requestBody = {
    "Inputs": {
      "input1": [
        {
          'Diabetes_012': "1",
          'HighBP': "1",
          'HighChol': "1",
          'CholCheck': "1",
          'BMI': "1",
          'Smoker': "1",
          'Stroke': "1",
          'HeartDiseaseorAttack': "1",
          'PhysActivity': "1",
          'Fruits': "1",
          'Veggies': "1",
          'HvyAlcoholConsump': "1",
          'AnyHealthcare': "1",
          'NoDocbcCost': "1",
          'GenHlth': "1",
          'MentHlth': "1",
          'PhysHlth': "1",
          'DiffWalk': "1",
          'Sex': "1",
          'Age': "1",
          'Education': "1",
          'Income': "1",
        }
      ],
    },
    "GlobalParameters": {},
  };

  final response = await http.post(Uri.parse(url), headers: headers, body: json.encode(requestBody));

  if (response.statusCode == 200) {
    final predictionResult = json.decode(response.body);
    return predictionResult['Results']['output1'][0];
  } else {
    throw Exception('Failed to make the prediction request');
  }
}

// Example usage
void fetchAndDisplayPrediction(BuildContext context, Map<String, dynamic> formData) async {
  try {
    final url = 'https://ussouthcentral.services.azureml.net/workspaces/e339cb2ecdf047b885e8e56f8c4c7892/services/d1df4ea11add402ea258a67853d558a8/execute?api-version=2.0&format=swagger'; // Replace with your Flask API endpoint
    final headers = {'Content-Type': 'application/json'};

    final response = await http.post(
      Uri.parse(url),
      headers: headers,
      body: jsonEncode(formData),
    );

    if (response.statusCode == 200) {
      final predictionResult = jsonDecode(response.body);
      final disease = predictionResult['HeartDiseaseorAttack'];
      final probability = predictionResult['Probability'];

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PredictionPage(
            disease: disease,
            probability: probability,
          ),
        ),
      );
    } else {
      throw Exception('Failed to make the prediction request');
    }
  } catch (e) {
    print('Error: $e');
  }
}