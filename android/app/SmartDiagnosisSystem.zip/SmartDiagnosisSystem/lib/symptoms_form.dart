import 'package:flutter/material.dart';
import 'package:smartdiagnosissystem/heart_disease.dart';
import 'package:smartdiagnosissystem/diabetes.dart';
import 'package:smartdiagnosissystem/covid.dart';

class SymptomsCollector extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Symptom Collector'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HeartDiseaseSymptomsForm()),
                );
              },
              child: Text('Heart Disease'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DiabetesSymptomsForm()),
                );
              },
              child: Text('Diabetes'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CovidSymptomsForm()),
                );
              },
              child: Text('COVID'),
            ),
          ],
        ),
      ),
    );
  }
}

