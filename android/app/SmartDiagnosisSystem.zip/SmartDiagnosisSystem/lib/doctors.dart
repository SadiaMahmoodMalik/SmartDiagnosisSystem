import 'package:flutter/material.dart';
import 'package:faker/faker.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Doctor {
  final String name;
  final String specialization;
  final String location;
  final String hospital;

  Doctor({
    required this.name,
    required this.specialization,
    required this.location,
    required this.hospital,
  });

  void deleteDoctor(List<Doctor> doctors) {
    doctors.remove(this);
  }
}

List<Doctor> generateDummyDoctors(int count) {
  List<Doctor> doctors = [];

  final faker = Faker();

  List<String> specializations = ['Heart Specialist', 'COVID Specialist', 'Diabetes Specialist'];
  List<String> locations = ['Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Peshawar'];
  List<String> hospitals = [
    'Aga Khan University Hospital',
    'Lahore General Hospital',
    'Shifa International Hospital',
    'Rawalpindi Medical University',
    'Hayatabad Medical Complex'
  ];

  List<String> pakistaniMuslimFirstNames = [
    'Muhammad',
    'Ali',
    'Ahmed',
    'Hassan',
    'Usman',
    'Ibrahim',
    'Omar',
    'Abdullah',
    'Zainab',
    'Ayesha',
    'Fatima',
    'Khadija',
    'Maryam',
    'Sara',
    'Hafsa',
    'Zahra',
  ];

  List<String> pakistaniMuslimLastNames = [
    'Khan',
    'Ali',
    'Ahmed',
    'Raza',
    'Hussain',
    'Malik',
    'Mahmood',
    'Qureshi',
    'Sheikh',
    'Zaman',
    'Akhtar',
    'Iqbal',
    'Aziz',
    'Siddiqui',
    'Farooq',
    'Rashid',
  ];

  for (int i = 0; i < count; i++) {
    String firstName = pakistaniMuslimFirstNames[i % pakistaniMuslimFirstNames.length];
    String lastName = pakistaniMuslimLastNames[(i + 1) % pakistaniMuslimLastNames.length];
    String name = 'Dr. $firstName $lastName';
    String specialization = specializations[i % specializations.length];
    String location = locations[i % locations.length];
    String hospital = hospitals[i % hospitals.length];

    Doctor doctor = Doctor(
      name: name,
      specialization: specialization,
      location: location,
      hospital: hospital,
    );
    doctors.add(doctor);
  }

  return doctors;
}

class DoctorsPage extends StatefulWidget {
  final List<Doctor> doctors;

  DoctorsPage({required this.doctors});

  @override
  _DoctorsPageState createState() => _DoctorsPageState();
}

class _DoctorsPageState extends State<DoctorsPage> {
  void deleteDoctor(Doctor doctor) {
    setState(() {
      doctor.deleteDoctor(widget.doctors);
      Fluttertoast.showToast(
        msg: 'Doctor ${doctor.name} deleted',
        gravity: ToastGravity.BOTTOM,
      );
    });
  }

  void addDoctor() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String name = '';
        String specialization = '';
        String location = '';
        String hospital = '';

        return AlertDialog(
          title: Text('Add Doctor'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                onChanged: (value) => name = value,
                decoration: InputDecoration(labelText: 'Name'),
              ),
              TextField(
                onChanged: (value) => specialization = value,
                decoration: InputDecoration(labelText: 'Specialization'),
              ),
              TextField(
                onChanged: (value) => location = value,
                decoration: InputDecoration(labelText: 'Location'),
              ),
              TextField(
                onChanged: (value) => hospital = value,
                decoration: InputDecoration(labelText: 'Hospital'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (name.isNotEmpty && specialization.isNotEmpty && location.isNotEmpty && hospital.isNotEmpty) {
                  Doctor newDoctor = Doctor(
                    name: name,
                    specialization: specialization,
                    location: location,
                    hospital: hospital,
                  );
                  setState(() {
                    widget.doctors.add(newDoctor);
                  });
                  Navigator.of(context).pop();
                  Fluttertoast.showToast(
                    msg: 'Doctor added',
                    gravity: ToastGravity.BOTTOM,
                  );
                }
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctors'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: addDoctor,
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: widget.doctors.length,
        itemBuilder: (context, index) {
          Doctor doctor = widget.doctors[index];
          return GestureDetector(
            onTap: () {
              // Handle doctor tap event
              print('Doctor tapped: ${doctor.name}');
            },
            child: Card(
              elevation: 2.0,
              margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.grey, width: 1.0),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: ListTile(
                contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                title: Text(
                  doctor.name,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 5.0),
                    Text(
                      'Specialization: ${doctor.specialization}',
                      style: TextStyle(color: Colors.blue),
                    ),
                    SizedBox(height: 2.0),
                    Text(
                      'Location: ${doctor.location}',
                      style: TextStyle(color: Colors.blue),
                    ),
                    SizedBox(height: 2.0),
                    Text(
                      'Hospital: ${doctor.hospital}',
                      style: TextStyle(color: Colors.blue),
                    ),
                  ],
                ),
                trailing: IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () => deleteDoctor(doctor),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

void main() {
  final doctors = generateDummyDoctors(10);

  runApp(MaterialApp(
    title: 'Doctors App',
    home: DoctorsPage(doctors: doctors),
  ));
}
