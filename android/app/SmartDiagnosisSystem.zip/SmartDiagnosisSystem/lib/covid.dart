import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:smartdiagnosissystem/report.dart';

class CovidSymptomsForm extends StatefulWidget {
  @override
  _CovidSymptomsFormState createState() => _CovidSymptomsFormState();
}

class _CovidSymptomsFormState extends State<CovidSymptomsForm> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  Map<String, bool> selectedSymptoms = {};
  String selectedAgeGroup = '';
  String selectedGender = '';
  String selectedSeverity = '';
  String selectedContactOption = '';

  List<String> symptoms = [
    'Fever',
    'Tiredness',
    'Dry-Cough',
    'Difficulty-in-Breathing',
    'Sore-Throat',
    'None_Symptom',
    'Pains',
    'Nasal-Congestion',
    'Runny-Nose',
    'Diarrhea',
    'None_Experiencing',
  ];

  List<String> ageGroups = [
    '0-9',
    '10-19',
    '20-24',
    '25-59',
    '60+',
  ];

  List<String> genders = [
    'Female',
    'Male',
    'Transgender',
  ];

  List<String> severities = [
    'Mild',
    'Moderate',
    'None',
    'Severe',
  ];

  List<String> contactOptions = [
    'Dont-Know',
    'No',
    'Yes',
  ];

  @override
  void initState() {
    super.initState();
    symptoms.forEach((symptom) {
      selectedSymptoms[symptom] = false;
    });
  }

  Future<void> saveSymptoms() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        final databaseRef = FirebaseDatabase.instance.ref().child('covid');
        final savedSymptomsRef = await databaseRef.push();
        final Map<String, dynamic> savedSymptoms = {
          'selectedSymptoms': selectedSymptoms,
          'selectedAgeGroup': selectedAgeGroup,
          'selectedGender': selectedGender,
          'selectedSeverity': selectedSeverity,
          'selectedContactOption': selectedContactOption,
        };
        await savedSymptomsRef.set(savedSymptoms);

        final savedSymptomsId = savedSymptomsRef.key;

        print('Symptoms ID: $savedSymptomsId');

        setState(() {
          _isLoading = false;
        });
      } catch (error) {
        setState(() {
          _isLoading = false;
        });
        // Handle the database save error case
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('COVID-19 Symptoms Collector'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Please enter your COVID-19 symptoms:',
                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Select Symptoms:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Wrap(
                  spacing: 8.0,
                  children: symptoms.map((symptom) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Checkbox(
                          value: selectedSymptoms[symptom],
                          onChanged: (value) {
                            setState(() {
                              selectedSymptoms[symptom] = value!;
                            });
                          },
                        ),
                        Text(symptom),
                      ],
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Select Age Group:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Wrap(
                  spacing: 8.0,
                  children: ageGroups.map((ageGroup) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio(
                          value: ageGroup,
                          groupValue: selectedAgeGroup,
                          onChanged: (value) {
                            setState(() {
                              selectedAgeGroup = value.toString();
                            });
                          },
                        ),
                        Text(ageGroup),
                      ],
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Select Gender:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Wrap(
                  spacing: 8.0,
                  children: genders.map((gender) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio(
                          value: gender,
                          groupValue: selectedGender,
                          onChanged: (value) {
                            setState(() {
                              selectedGender = value.toString();
                            });
                          },
                        ),
                        Text(gender),
                      ],
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Select Severity:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Wrap(
                  spacing: 8.0,
                  children: severities.map((severity) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio(
                          value: severity,
                          groupValue: selectedSeverity,
                          onChanged: (value) {
                            setState(() {
                              selectedSeverity = value.toString();
                            });
                          },
                        ),
                        Text(severity),
                      ],
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Select Contact Option:',
                  style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                ),
                Wrap(
                  spacing: 8.0,
                  children: contactOptions.map((contactOption) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Radio(
                          value: contactOption,
                          groupValue: selectedContactOption,
                          onChanged: (value) {
                            setState(() {
                              selectedContactOption = value.toString();
                            });
                          },
                        ),
                        Text(contactOption),
                      ],
                    );
                  }).toList(),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: saveSymptoms,
                  child: Text('Submit'),
                ),
                ElevatedButton(
                  onPressed: () {
           //         generateMedicalReport();
                  },
                  child: Text('Report'),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
